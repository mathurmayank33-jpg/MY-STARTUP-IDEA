import streamlit as st
import pandas as pd
from pathlib import Path

st.set_page_config(page_title="Syncra | Agri Export Marketplace", page_icon="🌾", layout="wide")

DATA = Path(__file__).parent / "data" / "sample_data.csv"

@st.cache_data
def load_data():
    return pd.read_csv(DATA)

df = load_data()

def match_score(row, product, qty, country, certification):
    score = 0
    score += 40 if str(row["product"]).lower() == product.lower() else 0
    score += min(25, int(row["capacity_kg"]) / max(qty, 1) * 25) if row["capacity_kg"] >= qty else 0
    score += 20 if country.lower() in str(row["target_markets"]).lower() else 5
    score += 15 if certification.lower() in str(row["certifications"]).lower() else 0
    return round(min(score, 100))

st.title("🌾 Syncra")
st.caption("AI-assisted farmer-to-buyer export marketplace — Product Management Portfolio Prototype")

with st.sidebar:
    st.header("Demo Controls")
    page = st.radio("Navigate", ["Product Overview", "Buyer RFQ", "Supplier Matches", "Analytics"])

if page == "Product Overview":
    st.subheader("Product thesis")
    st.write("Make agricultural export sourcing simpler, faster and more reliable by structuring the buyer RFQ → supplier match → quote → export-readiness journey.")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Suppliers", len(df))
    c2.metric("Products", df["product"].nunique())
    c3.metric("Target markets", df["target_markets"].nunique())
    c4.metric("Verified suppliers", int(df["verified"].sum()))
    st.divider()
    st.subheader("Core workflow")
    st.write("Buyer creates RFQ → Syncra structures requirements → matching engine ranks suppliers → buyer compares quotes → supplier completes export-readiness checklist.")
    st.info("Product decision: start with explainable rules-based matching. Add ML only after enough historical RFQ/quote data exists.")

elif page == "Buyer RFQ":
    st.subheader("Create a structured buyer RFQ")
    col1, col2 = st.columns(2)
    with col1:
        product = st.selectbox("Product", sorted(df["product"].unique()))
        quantity = st.number_input("Required quantity (kg)", min_value=500, value=5000, step=500)
        country = st.selectbox("Destination market", ["Saudi Arabia", "Qatar", "UAE", "Oman"])
    with col2:
        certification = st.selectbox("Required certification", ["APEDA", "ISO", "HACCP"])
        quality = st.selectbox("Quality requirement", ["Standard", "Premium", "Organic"])
        deadline = st.date_input("Quote deadline")
    notes = st.text_area("Buyer notes", placeholder="Packaging, moisture %, delivery window, Incoterms...")
    if st.button("Generate RFQ & Find Matches", type="primary"):
        st.success("RFQ structured successfully. Matching suppliers below.")
        st.session_state["rfq"] = dict(product=product, quantity=quantity, country=country, certification=certification, quality=quality, notes=notes, deadline=str(deadline))
        matches = df.copy()
        matches["match_score"] = matches.apply(lambda r: match_score(r, product, quantity, country, certification), axis=1)
        matches = matches.sort_values("match_score", ascending=False).head(5)
        st.dataframe(matches[["supplier","product","capacity_kg","certifications","target_markets","match_score"]], use_container_width=True)
        st.caption("AI-assisted next action: ask the top 3 suppliers for quote, lead time and export-document readiness.")

elif page == "Supplier Matches":
    st.subheader("Explainable supplier matching")
    product = st.selectbox("Product", sorted(df["product"].unique()), key="m_product")
    quantity = st.number_input("Quantity (kg)", min_value=500, value=5000, step=500, key="m_qty")
    country = st.selectbox("Destination", ["Saudi Arabia", "Qatar", "UAE", "Oman"], key="m_country")
    certification = st.selectbox("Certification", ["APEDA", "ISO", "HACCP"], key="m_cert")
    ranked = df.copy()
    ranked["match_score"] = ranked.apply(lambda r: match_score(r, product, quantity, country, certification), axis=1)
    ranked = ranked.sort_values("match_score", ascending=False)
    st.dataframe(ranked[["supplier","product","capacity_kg","price_per_kg","certifications","target_markets","match_score"]], use_container_width=True)
    st.subheader("Why this match?")
    st.write("Score = product fit (40) + capacity fit (25) + destination-market fit (20) + certification fit (15).")
    st.caption("This explanation is intentionally deterministic so product, engineering and operations teams can audit the MVP.")

elif page == "Analytics":
    st.subheader("Product health dashboard")
    total_rfqs = 240
    qualified = 164
    quotes = 102
    wins = 31
    a, b, c, d = st.columns(4)
    a.metric("RFQs", total_rfqs)
    b.metric("Qualified RFQs", qualified, "68.3%")
    c.metric("Quotes received", quotes, "62.2% of qualified")
    d.metric("Deals won", wins, "30.4% of quotes")
    st.divider()
    funnel = pd.DataFrame({
        "Stage": ["RFQ created", "Qualified", "Quote received", "Deal won"],
        "Users": [total_rfqs, qualified, quotes, wins]
    })
    st.bar_chart(funnel.set_index("Stage"))
    st.subheader("Suggested product actions")
    st.write("1. Improve RFQ qualification where users abandon before submitting specifications.")
    st.write("2. Reduce supplier response time with automated follow-up reminders.")
    st.write("3. Investigate why quoted deals do not convert into orders.")
    st.write("4. Track match-score calibration against actual buyer selections.")

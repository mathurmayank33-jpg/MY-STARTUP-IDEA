# UAT / QA Test Cases

| ID | Scenario | Steps | Expected |
|---|---|---|---|
| QA-01 | Valid RFQ | Select rice, 5,000 kg, Saudi Arabia, APEDA → submit | RFQ succeeds and matches appear |
| QA-02 | Zero quantity | Enter 0 kg | Validation prevents invalid request |
| QA-03 | Capacity mismatch | Request more than supplier capacity | Supplier score is reduced |
| QA-04 | Certification match | Select HACCP | Suppliers with HACCP receive certification points |
| QA-05 | Explainability | Open match results | Score logic is visible |
| QA-06 | Dashboard | Open Analytics | Funnel metrics render |
| QA-07 | Unknown supplier verification | Inspect unverified supplier | UI does not claim verified status |
| QA-08 | Empty notes | Submit without optional notes | RFQ still succeeds |

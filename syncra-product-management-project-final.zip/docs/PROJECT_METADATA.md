# GitHub Project Metadata

## Suggested repository name

`syncra-product-management-mvp`

## Suggested description

AI-assisted agri-export marketplace MVP demonstrating PRD, user stories, explainable supplier matching, experimentation, analytics and QA/UAT.

## Suggested topics

`product-management` `product-management-portfolio` `streamlit` `marketplace` `ai-product` `analytics` `prd` `product-analytics` `agritech`

## Suggested pinned-project description

Built an end-to-end product case around Syncra: structured buyer RFQs, explainable supplier matching, funnel analytics, AI-assisted workflows, experiments and UAT.

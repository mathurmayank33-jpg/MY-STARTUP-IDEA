# Syncra — Interview Story

## Situation

International agricultural sourcing can involve fragmented supplier discovery, repeated clarification and manual comparison.

## Task

Design a product that reduces friction between a buyer's requirement and a qualified supplier shortlist.

## Action

1. Defined buyer and supplier personas.
2. Converted the problem into a structured RFQ workflow.
3. Created a deterministic supplier matching model.
4. Added explainability so users can understand recommendations.
5. Defined the RFQ → quote funnel and north-star metric.
6. Designed an A/B test for guided versus free-form RFQs.
7. Added QA/UAT cases.
8. Built a Streamlit prototype.

## Key product decision

I chose explainable rules before ML.

The reason is simple: an early marketplace may not have enough labeled historical data to train and validate a ranking model. An auditable rules engine creates useful product behavior and generates the event data needed for future intelligence.

## What I would do next

Run 10 discovery interviews and test the biggest assumptions before expanding scope.

## What I learned

A good PM project is not defined by how many features are built. It is defined by whether the product clearly connects:

**user problem → product decision → measurable outcome → learning loop.**

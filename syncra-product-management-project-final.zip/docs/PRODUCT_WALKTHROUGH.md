# Product Walkthrough

## 1. Start with the user problem
Open **Buyer RFQ** and create a sourcing request.

## 2. Show the product decision
Explain why Syncra asks for structured requirements instead of accepting only free text.

## 3. Demonstrate matching
Open **Supplier Matches**. Explain the transparent scoring model.

## 4. Demonstrate analytics
Open **Analytics**. Explain how a PM would identify funnel leakage and prioritize experiments.

## 5. Discuss AI
AI is deliberately used as an assistant rather than an opaque decision-maker:
- summarize RFQs
- identify missing information
- draft follow-ups
- explain recommendations

## 6. Discuss next iteration
The next sprint should validate the biggest assumption with real user interviews before adding ML complexity.

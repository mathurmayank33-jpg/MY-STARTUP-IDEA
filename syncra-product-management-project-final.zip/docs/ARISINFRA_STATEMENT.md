# ArisInfra Application Statement

I am excited about the Product Management Intern opportunity at ArisInfra because the role combines user problem-solving, analytics, experimentation and technology rather than treating product management as documentation alone.

For my portfolio, I built Syncra, an AI-assisted agricultural sourcing marketplace. The project started from a simple problem: international buyers may struggle to convert a sourcing requirement into a shortlist of relevant, qualified suppliers. I designed a structured RFQ workflow, an explainable supplier-matching model, a product metrics funnel, experimentation plan and UAT framework.

A key product decision was deliberately keeping the first matching model rules-based rather than immediately using machine learning. An early product may not have enough reliable historical outcomes to train a ranking model, so I prioritized transparency, auditability and fast iteration. The product then creates the data foundation for future ML-assisted ranking and anomaly detection.

I also built a working Streamlit prototype and documented the PRD, user stories, acceptance criteria, roadmap, experiments and QA cases. This project reflects how I like to work: start with the user problem, make assumptions explicit, build the smallest useful solution, measure outcomes and iterate.

ArisInfra's emphasis on real product ownership, cross-functional collaboration and AI-assisted workflows strongly matches the kind of environment in which I want to develop as a product professional.

# Syncra Product Architecture

```mermaid
flowchart TB
    Buyer[International Buyer] --> UI[Syncra Web App]
    Supplier[Supplier / Exporter] --> UI

    UI --> RFQ[RFQ Service]
    RFQ --> Validation[Requirement Validation]
    Validation --> Match[Explainable Matching Engine]

    Supplier --> Profiles[Supplier Profiles]
    Profiles --> Match

    Match --> Results[Ranked Supplier Results]
    Results --> Quotes[Quote Workflow]
    Quotes --> Readiness[Export Readiness Checklist]

    RFQ --> Events[Product Events]
    Results --> Events
    Quotes --> Events

    Events --> Analytics[Product Analytics]
    Analytics --> PM[Product Decisions]

    RFQ --> AI[AI Assistant]
    AI --> Summary[Summarization]
    AI --> Missing[Missing Info Detection]
    AI --> Followup[Follow-up Drafting]

    Match --> FutureML[Future ML Ranking]
    Events --> FutureML
```

## Data flow

1. Buyer submits structured RFQ.
2. Validation checks required information.
3. Matching engine scores suppliers.
4. Buyer receives ranked and explainable results.
5. Quotes and response times become product events.
6. Analytics measures funnel performance.
7. Historical outcomes eventually enable ML ranking.

# 🌾 Syncra — Intelligent Agri-Export Marketplace

### Product Management Portfolio Project | Mayank Mathur

**Syncra** is a product concept for simplifying international agricultural sourcing by connecting Indian agricultural suppliers with international buyers through structured RFQs, explainable supplier matching, quote comparison, and export-readiness workflows.

> **Portfolio objective:** demonstrate end-to-end Product Management thinking — discovery → PRD → prioritization → prototype → analytics → experimentation → QA/UAT → iteration.

---

## 🎯 Why this project?

International agricultural sourcing is often fragmented. A buyer may need to compare supplier capacity, product specifications, certifications, target markets and responsiveness before deciding whom to contact.

Syncra turns that fragmented process into a structured product journey:

```mermaid
flowchart LR
    A[Buyer need] --> B[Structured RFQ]
    B --> C[Requirement validation]
    C --> D[Supplier matching]
    D --> E[Explainable shortlist]
    E --> F[Quote comparison]
    F --> G[Export-readiness]
    G --> H[Order]
    H --> I[Analytics & learning]
    I --> D
```

---

# 🚀 MVP

### Buyer experience

- Create a structured RFQ
- Specify product, quantity, destination and certification
- Receive ranked supplier matches
- Understand **why** a supplier matched
- Compare supplier information
- Track sourcing funnel performance

### Supplier experience

- Maintain capacity and certification information
- Receive relevant buyer demand
- Respond to qualified RFQs
- Improve profile completeness and market coverage

### Product intelligence

- Rules-based explainable matching
- RFQ quality checks
- AI-assisted RFQ summarization concept
- Follow-up recommendations
- Funnel analytics
- Experimentation framework

---

# 🧠 Product Thinking

## North-star metric

**Qualified RFQ → Quote conversion rate**

Why?

A simple RFQ count can create vanity growth. The product's real value is helping serious buyer requirements reach relevant suppliers and generate meaningful commercial responses.

### Metrics tree

| Funnel | Metrics |
|---|---|
| Acquisition | New buyers, RFQ starts |
| Activation | RFQ completion, specification completeness |
| Matching | Match CTR, shortlist acceptance |
| Engagement | Supplier profile views, quote requests |
| Conversion | RFQ → quote, quote → order |
| Reliability | Supplier response time, failed RFQs |
| AI quality | AI summary acceptance, human override rate |

---

# 🔎 Product Discovery

### Key assumptions to validate

1. Buyers struggle more with **supplier qualification** than supplier discovery alone.
2. Structured RFQs improve supplier response quality.
3. Buyers want to understand why a supplier was recommended.
4. Supplier response time materially affects RFQ conversion.
5. AI assistance is valuable when it reduces administrative work without hiding decision logic.

### Discovery plan

**10 interviews**
- 5 international procurement/buyer personas
- 5 Indian suppliers/exporters

**Questions**

- How do you currently find suppliers?
- What information is difficult to verify?
- Where do sourcing requests get delayed?
- What makes you reject a supplier?
- What information do you need before requesting a quote?
- Would an explainable supplier score influence your shortlist?

---

# 📋 PRD

See [`product/PRD.md`](product/PRD.md).

The PRD defines:

- Problem statement
- Personas
- User journey
- MVP scope
- Functional requirements
- Non-functional requirements
- Metrics
- AI opportunities
- Product trade-offs

---

# 🧩 User Stories

Example:

> **As an international buyer, I want to create a structured RFQ so that relevant suppliers can respond without repeated clarification.**

Acceptance criteria include:

- Product is mandatory
- Quantity must be positive
- Destination is mandatory
- Certification can be specified
- Successful submission creates an RFQ
- Matching results are generated

See [`product/USER_STORIES.md`](product/USER_STORIES.md).

---

# 📊 Prioritization

I use:

### RICE-style thinking

**Priority = Reach × Impact × Confidence ÷ Effort**

| Feature | Reach | Impact | Confidence | Effort | Decision |
|---|---:|---:|---:|---:|---|
| Structured RFQ | High | High | High | Medium | 🚀 P0 |
| Explainable matching | High | High | High | Medium | 🚀 P0 |
| Quote comparison | Medium | High | Medium | Medium | P1 |
| AI RFQ summary | High | Medium | Medium | Low | P1 |
| ML ranking | Medium | High | Low | High | P2 |
| Computer vision quality inspection | Medium | High | Low | Very High | P3 |

### Product trade-off

I would **not start with ML ranking**.

The MVP uses a transparent rules-based score because early-stage products usually have limited historical outcome data. Once enough RFQ → supplier → quote → order outcomes are captured, ML ranking becomes easier to justify and evaluate.

---

# 🤖 AI Product Opportunities

Syncra treats AI as an assistant rather than an opaque decision-maker.

### MVP AI use cases

**1. RFQ summarizer**

Convert long buyer requirements into structured fields.

**2. Missing-information detector**

Identify missing quantity, packaging, quality, destination or deadline information.

**3. Supplier-match explanation**

Generate a human-readable explanation from deterministic match factors.

**4. Follow-up assistant**

Draft supplier follow-ups based on RFQ status.

### Later

- Learning-to-rank
- Price anomaly detection
- Demand forecasting
- Supplier response prediction

---

# 🧪 Experimentation

## Experiment: Guided RFQ vs Free-form enquiry

### Hypothesis

A guided RFQ will increase qualified RFQ completion because buyers receive prompts for critical information.

### A/B test

**Control:** Free-form enquiry

**Treatment:** Guided RFQ

### Primary metric

Qualified RFQ completion rate

### Guardrails

- Time to complete
- Buyer satisfaction
- Supplier response rate
- RFQ abandonment

### Ship rule

Ship the treatment if qualified completion improves by **≥10%** without materially worsening completion time or satisfaction.

See [`product/EXPERIMENTS.md`](product/EXPERIMENTS.md).

---

# 🧪 QA / UAT

The repository includes reproducible UAT cases for:

- Valid RFQ
- Invalid quantity
- Capacity mismatch
- Certification matching
- Explainability
- Dashboard rendering
- Verification status
- Optional fields

See [`qa/UAT_TEST_CASES.md`](qa/UAT_TEST_CASES.md).

---

# 📈 Demo Dashboard

The Streamlit prototype demonstrates:

- RFQ funnel
- Qualified RFQs
- Quotes
- Won deals
- Supplier matching
- Explainable scoring

Run:

```bash
pip install -r requirements.txt
streamlit run app.py
```

---

# 🗂️ Repository Structure

```text
syncra-product-management-project/
│
├── app.py
├── requirements.txt
├── README.md
├── LICENSE
│
├── data/
│   └── sample_data.csv
│
├── product/
│   ├── PRD.md
│   ├── USER_STORIES.md
│   ├── ROADMAP.md
│   ├── EXPERIMENTS.md
│   ├── METRICS.md
│   └── COMPETITIVE_SCAN.md
│
├── qa/
│   └── UAT_TEST_CASES.md
│
├── docs/
│   ├── PRODUCT_WALKTHROUGH.md
│   ├── INTERVIEW_STORY.md
│   └── ARISINFRA_STATEMENT.md
│
└── assets/
    └── architecture.md
```

---

# 💼 ArisInfra Role Alignment

This project is intentionally mapped to the Product Management Intern requirements in the provided job description.

| ArisInfra requirement | Syncra evidence |
|---|---|
| Maintain roadmap & backlog | Roadmap + prioritization |
| User stories & acceptance criteria | `USER_STORIES.md` |
| Lightweight PRDs | `PRD.md` |
| Experiments & usability testing | `EXPERIMENTS.md` |
| Market/competitive scan | `COMPETITIVE_SCAN.md` |
| AI-assisted workflows | AI product opportunities |
| Success metrics & dashboards | `METRICS.md` + Streamlit |
| QA/UAT | `UAT_TEST_CASES.md` |
| Documentation | Product walkthrough |
| Product thinking | Explicit MVP trade-offs |
| Analytical problem solving | Matching model + metrics tree |

---

# 🎤 90-Second Interview Pitch

> “I built Syncra as a product-management case project around agricultural export sourcing. The core problem I wanted to solve was not simply supplier discovery, but the friction between a buyer having a requirement and finding a supplier who is actually relevant and ready to respond.
>
> I started with a structured RFQ, then designed an explainable matching system using product fit, capacity, destination-market fit and certification. I deliberately chose a rules-based approach for the MVP instead of jumping directly to ML because early-stage data would not be sufficient for reliable learning-to-rank.
>
> I then built the product funnel around RFQ creation, qualification, quote receipt and deal conversion, and defined the north-star metric as qualified-RFQ-to-quote conversion.
>
> I also documented user stories, acceptance criteria, experiments and UAT cases. The next product question I would validate through user interviews is whether guided RFQs actually improve qualified sourcing outcomes compared with free-form enquiries.
>
> The project demonstrates how I approach ambiguous problems: understand the user, define the smallest useful product, make trade-offs explicit, measure outcomes and iterate.”

---

# 📌 Resume Version

**Syncra — Product Management & AI Marketplace Project**

- Designed an end-to-end agri-export marketplace concept connecting international buyers with Indian suppliers through structured RFQs and explainable supplier matching.
- Authored PRD, user stories, acceptance criteria, roadmap, experimentation framework, metrics tree and UAT test cases.
- Built a Streamlit MVP with RFQ creation, supplier ranking, explainable match scoring and product funnel analytics.
- Designed AI-assisted workflows for RFQ summarization, missing-information detection and supplier follow-up recommendations.
- Prioritized an explainable rules-based MVP over ML ranking to reduce dependency on historical training data and improve decision transparency.

---

## ⚠️ Portfolio disclaimer

This is a **portfolio prototype using synthetic data**. Supplier names, pricing, metrics and marketplace outcomes are illustrative and should not be represented as real commercial data.

---

### Built by Mayank Mathur
MBA — Marketing & Business Analytics  
Product Management • Analytics • AI-assisted Product Thinking

# Metrics Tree

## North Star
**Qualified RFQ → Quote conversion rate**

### Acquisition
- new buyers
- RFQ starts

### Activation
- RFQ completion rate
- % RFQs with all mandatory specifications

### Engagement
- supplier profile views
- match clicks
- quote requests per RFQ

### Conversion
- qualified RFQ → quote
- quote → order

### Reliability
- median supplier response time
- failed RFQs
- data completeness

### AI quality
- % AI summaries accepted without edit
- recommendation click-through
- human override rate

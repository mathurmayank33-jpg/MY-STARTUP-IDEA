# PRD — Syncra Intelligent RFQ & Supplier Matching

## 1. Objective

Help an international buyer move from an agricultural sourcing requirement to a shortlist of qualified Indian suppliers in minutes rather than through fragmented manual outreach.

## 2. Users

### Primary
International buyer/procurement manager sourcing rice, wheat, pulses or spices.

### Secondary
Indian farmer collective, supplier, aggregator or exporter.

## 3. User problem

Buyers must compare fragmented supplier information, capacity, certification and market experience. Suppliers receive unstructured enquiries and spend time clarifying basic requirements.

## 4. User story

As a buyer, I want to create a structured RFQ and receive explainable supplier matches so that I can quickly contact the most relevant suppliers.

## 5. MVP requirements

- RFQ form captures product, quantity, destination, certification, quality and deadline.
- Supplier records contain capacity, certifications, markets and verification state.
- Matching engine produces ranked suppliers.
- Match explanation shows why a supplier ranked highly.
- Buyer can compare supplier quotes.
- Dashboard tracks RFQ funnel health.

## 6. Non-functional requirements

- Explainable matching
- Clear validation errors
- Responsive UI
- Synthetic demo data only
- No automated trade/compliance claims without verification

## 7. Success metrics

Primary: qualified-RFQ-to-quote conversion.

Secondary:
- RFQ completion rate
- median time to first supplier response
- match acceptance rate
- quote-to-order conversion
- supplier response rate

## 8. AI opportunities

Phase 1:
- RFQ summarization
- suggested missing fields
- buyer follow-up draft
- supplier match explanation

Phase 2:
- learn-to-rank model from historical outcomes
- anomaly detection on pricing/response patterns

## 9. Trade-offs

A deterministic matching score is preferred for MVP because it is auditable and requires less historical training data. ML should be introduced after reliable outcome labels exist.

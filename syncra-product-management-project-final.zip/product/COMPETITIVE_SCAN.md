# Lightweight Competitive Scan

This is a product-positioning exercise rather than a claim of exhaustive market research.

| Alternative | Buyer discovery | Structured RFQ | Explainable matching | Export readiness |
|---|---:|---:|---:|---:|
| Traditional broker | Medium | Low | Low | High |
| Generic B2B marketplace | High | Medium | Low | Medium |
| Direct supplier outreach | Low | Low | Low | Variable |
| **Syncra MVP** | High | High | High | Medium |

## Product opportunity

Do not compete only on supplier listings. The differentiated workflow is:
**structured demand → qualified matching → explainable recommendations → quote comparison → readiness.**

# Product Roadmap

## Phase 0 — Discovery
- Interview 5 buyers
- Interview 5 suppliers/exporters
- Map current sourcing workflow
- Validate top pain points

## Phase 1 — MVP
- Structured RFQ
- Supplier verification fields
- Explainable matching
- Quote comparison
- Basic funnel dashboard

## Phase 2 — Automation
- RFQ summarization
- Automated follow-up reminders
- Export-readiness checklist
- Supplier response alerts

## Phase 3 — Intelligence
- Historical match-performance analysis
- ML-assisted ranking
- Pricing anomaly detection
- Personalized buyer recommendations

## Prioritization framework

Score each item using:
**Impact × Confidence ÷ Effort**

High-impact, high-confidence and low-effort items ship first.

# Product Experiments

## Experiment 1 — Guided RFQ vs free-form enquiry

### Hypothesis
A structured guided RFQ will increase completed qualified RFQs because users receive prompts for critical information.

### Variants
A: current free-form enquiry
B: guided RFQ form

### Primary metric
Qualified RFQ completion rate.

### Guardrails
- time to complete RFQ
- buyer satisfaction
- supplier response rate

### Decision rule
Ship B if completion improves by >=10% without materially reducing satisfaction or increasing completion time.

## Experiment 2 — Explainable matching

Compare ranked supplier results with and without score explanations.

**Hypothesis:** explanations increase match acceptance because buyers understand why a supplier was recommended.

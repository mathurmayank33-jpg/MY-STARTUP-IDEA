# User Stories & Acceptance Criteria

## US-01 — Create RFQ
**As a buyer**, I want to enter structured sourcing requirements so suppliers receive a clear request.

**Acceptance criteria**
- Product is mandatory.
- Quantity must be greater than zero.
- Destination is mandatory.
- Required certification can be selected.
- Submission produces an RFQ confirmation.

## US-02 — Rank suppliers
**As a buyer**, I want relevant suppliers ranked by fit.

**Acceptance criteria**
- Results are sorted by match score.
- Capacity mismatch reduces the score.
- Certification fit is visible.
- Product fit is visible.
- No supplier is presented as verified unless the data says verified.

## US-03 — Explain match
**As a buyer**, I want to know why a supplier is recommended.

**Acceptance criteria**
- Score components are shown.
- Explanation uses plain language.
- No unsupported claims are generated.

## US-04 — Track funnel
**As a product manager**, I want to see RFQ funnel metrics so I can identify drop-offs.

**Acceptance criteria**
- RFQs, qualified RFQs, quotes and wins are visible.
- Conversion rates are calculable.
- Dashboard suggests product actions based on observed drop-offs.
